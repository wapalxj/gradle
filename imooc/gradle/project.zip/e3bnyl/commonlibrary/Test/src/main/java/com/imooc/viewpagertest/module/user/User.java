package com.imooc.viewpagertest.module.user;


import com.imooc.viewpagertest.module.BaseModel;

/**
 * Created by renzhiqiang on 15/11/20.
 */
public class User extends BaseModel {
    public int ecode;
    public String emsg;
    public UserContent data;
}
