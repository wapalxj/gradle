package com.lianjia.pullalive;

/**
 * 创建时间:  2016/09/07 <br>
 * 作者:  fujia <br>
 * 描述:  环境类
 */
public class Env {
  public static boolean DEBUG = true;
}
