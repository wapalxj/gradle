package com.youdu.module.recommand;

import com.youdu.module.BaseModel;

/**
 * @author: vision
 * @function:
 * @date: 16/9/2
 */
public class RecommandFooterValue extends BaseModel {

    public String title;
    public String info;
    public String from;
    public String imageOne;
    public String imageTwo;
    public String destationUrl;
}
