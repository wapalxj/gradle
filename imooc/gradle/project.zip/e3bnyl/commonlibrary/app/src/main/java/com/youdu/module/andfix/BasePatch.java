package com.youdu.module.andfix;

import com.youdu.module.BaseModel;
import com.youdu.module.user.UserContent;

/**
 * Created by qndroid on 17/1/14.
 */

public class BasePatch extends BaseModel {
    public int ecode;
    public String emsg;
    public PatchInfo data;
}
