package com.youdu.module.recommand;

import com.youdu.module.BaseModel;

/**
 * Created by renzhiqiang on 16/8/28.
 */
public class BaseRecommandModel extends BaseModel {

    public String ecode;
    public String emsg;
    public RecommandModel data;
}
