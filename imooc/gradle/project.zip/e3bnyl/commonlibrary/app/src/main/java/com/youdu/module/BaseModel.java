package com.youdu.module;

import java.io.Serializable;

/**
 * @description 实体基类
 * @author fangyan
 * @date 2015年8月1日
 */
public class BaseModel implements Serializable {

	private static final long serialVersionUID = 1L;
}
