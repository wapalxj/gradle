package com.youdu.util;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.youdu.module.recommand.RecommandBodyValue;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Hashtable;

/**
 * @author: vision
 * @function:
 * @date: 16/8/16
 */
public class Util {

  public static Bitmap createQRCode(int width, int height, String source) {
    try {
      if (TextUtils.isEmpty(source)) {
        return null;
      }
      Hashtable<EncodeHintType, String> hints = new Hashtable<>();
      hints.put(EncodeHintType.CHARACTER_SET, "utf-8");
      BitMatrix bitMatrix =
          new QRCodeWriter().encode(source, BarcodeFormat.QR_CODE, width, height, hints);
      int[] pixels = new int[width * height];
      for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
          if (bitMatrix.get(x, y)) {
            pixels[y * width + x] = 0xff000000;
          } else {
            pixels[y * width + x] = 0xffffffff;
          }
        }
      }
      // sheng chen de er wei ma
      Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
      bitmap.setPixels(pixels, 0, width, 0, 0, width, height);
      return bitmap;
    } catch (WriterException e) {
      e.printStackTrace();
    }
    return null;
  }

  public static int getVersionCode(Context context) {
    int versionCode = 1;
    try {
      PackageManager pm = context.getPackageManager();
      PackageInfo pi = pm.getPackageInfo(context.getPackageName(), 0);
      versionCode = pi.versionCode;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return versionCode;
  }

  public static String getVersionName(Context context) {
    String versionName = "1.0.0";
    try {
      PackageManager pm = context.getPackageManager();
      PackageInfo pi = pm.getPackageInfo(context.getPackageName(), 0);
      versionName = pi.versionName;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return versionName;
  }

  public static Uri createQQUrl(String qq) {
    String result = "mqqwpa://im/chat?chat_type=wpa&uin=".concat(qq);
    return Uri.parse(result);
  }

  //为ViewPager结构化数据
  public static ArrayList<RecommandBodyValue> handleData(RecommandBodyValue value) {
    ArrayList<RecommandBodyValue> values = new ArrayList<>();
    String[] titles = value.title.split("@");
    String[] infos = value.info.split("@");
    String[] prices = value.price.split("@");
    String[] texts = value.text.split("@");
    ArrayList<String> urls = value.url;
    int start = 0;
    for (int i = 0; i < titles.length; i++) {
      RecommandBodyValue tempValue = new RecommandBodyValue();
      tempValue.title = titles[i];
      tempValue.info = infos[i];
      tempValue.price = prices[i];
      tempValue.text = texts[i];
      tempValue.url = extractData(urls, start, 3);
      start += 3;

      values.add(tempValue);
    }
    return values;
  }

  private static ArrayList<String> extractData(ArrayList<String> source, int start, int interval) {
    ArrayList<String> tempUrls = new ArrayList<>();
    for (int i = start; i < start + interval; i++) {
      tempUrls.add(source.get(i));
    }
    return tempUrls;
  }

  /**
   * 显示系统软件盘
   * 传入的View必须是EditText及其子类才可以强制显示出
   */
  public static void showSoftInputMethod(Context context, View v) {
        /* 隐藏软键盘 */
    InputMethodManager inputMethodManager =
        (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
    inputMethodManager.showSoftInput(v, InputMethodManager.SHOW_FORCED);
  }

  public static void hideSoftInputMethod(Context context, View v) {
        /* 隐藏软键盘 */
    InputMethodManager inputMethodManager =
        (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
    inputMethodManager.hideSoftInputFromWindow(v.getWindowToken(), 0);
  }

  public static void hasError() {
    String error = "error";
    Log.e("Util", error);
  }

  /**
   * 返回当前的进程名
   */
  public static String getCurrentProcessName() {
    FileInputStream in = null;
    try {
      String fn = "/proc/self/cmdline";
      in = new FileInputStream(fn);
      byte[] buffer = new byte[256];
      int len = 0;
      int b;
      while ((b = in.read()) > 0 && len < buffer.length) {
        buffer[len++] = (byte) b;
      }
      if (len > 0) {
        String s = new String(buffer, 0, len, "UTF-8");
        return s;
      }
    } catch (Throwable e) {
      e.getMessage();
    } finally {
      if (in != null) {
        try {
          in.close();
        } catch (Throwable e) {
        }
      }
    }
    return null;
  }

  //判断指定的进程名是否是UI进程
  public static boolean isUIProcess(@NonNull String uiProcessName) {
    String sRuntimeProcessName = getCurrentProcessName();
    return uiProcessName.equals(sRuntimeProcessName) ? true : false;
  }
}
