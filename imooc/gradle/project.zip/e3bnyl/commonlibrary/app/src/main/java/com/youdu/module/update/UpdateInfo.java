package com.youdu.module.update;

import com.youdu.module.BaseModel;

/**
 * Created by renzhiqiang on 16/8/23.
 */
public class UpdateInfo extends BaseModel {

    public int currentVersion;
}
