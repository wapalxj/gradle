package objectorention

trait DefualtAction {

    abstract void eat()

    void play() {
        println ' i can play.'
    }

}