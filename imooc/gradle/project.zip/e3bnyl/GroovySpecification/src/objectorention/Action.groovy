package objectorention

/**
 * 接口中不许定义非public的方法
 */
interface Action {

    void eat()

    void drink()

    void play()
}