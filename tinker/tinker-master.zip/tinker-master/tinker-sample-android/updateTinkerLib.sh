#!/usr/bin/env bash
rm -rf ~/.gradle/caches/modules-2/metadata-2.16/descriptors/com.tencent.tinker

#rm -rf ~/.m2/repository/com/tencent/tinker
#adb push ./app/build/outputs/tinkerPatch/debug/patch_signed_7zip.apk /sdcard/